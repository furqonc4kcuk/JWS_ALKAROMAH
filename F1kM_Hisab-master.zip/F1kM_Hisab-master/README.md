# Hisab Hijr Date using Ephemeris Calculations
F1kM_Hisab is extended class of Ephemeris class from https://github.com/MarScaper/ephemeris

Calculate Hijr Date library using Ephemeris methode for Arduino IDE (C++), compare position of the moon when the sun sets (Hilal) on a certain date and a few days before.

by F1kM (For 1000 Masjid / Untuk 1000 Masjid) https://www.facebook.com/groups/761058907424496/
